from django.apps import AppConfig


class SongConfig(AppConfig):
    name = 'song'
