from django.apps import AppConfig


class ArtistConfig(AppConfig):
    name = 'artist'
