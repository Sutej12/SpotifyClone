from django.apps import AppConfig


class FavoriteConfig(AppConfig):
    name = 'favorite'
