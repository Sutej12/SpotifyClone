from django.apps import AppConfig


class GenreConfig(AppConfig):
    name = 'genre'
